// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

#pragma once

#include "opentelemetry/config.h"
#include "opentelemetry/sdk/common/global_log_handler.h"
